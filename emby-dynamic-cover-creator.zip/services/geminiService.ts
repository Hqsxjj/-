
// 该文件已被移除，当前应用使用纯 CSS 布局模拟器。
export const placeholder = {};
